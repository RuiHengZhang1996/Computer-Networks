In this project, user should input the following one by one:

Enter the number of messages to simulate: 10(e.g.)

Enter  packet loss probability [enter 0.0 for no loss]: 0.3

Enter packet corruption probability [0.0 for no corruption]:0.1

Enter average time between messages from sender's layer5 [ > 0.0]:1000

Enter TRACE:2

Go-Back-N programming part includes the functions below:
A_output(),A_input(),A_timerinterrupt(),A_init(),B_input(), and B_init() 

While the ABP programming part includes the functions below: 
A_output(), A_input(), A_timerinterrupt(), A_init(), B_input(), and B_init()